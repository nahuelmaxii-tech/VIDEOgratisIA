# VideoIA Gratis — web adaptable al celular

Proyecto inicial de una web responsive para texto-a-video e imagen-a-video usando un Space público de Gradio/Hugging Face.

## Importante sobre el costo
- Los archivos de esta web no tienen costo.
- Se puede alojar gratis como sitio estático (por ejemplo, GitHub Pages).
- La generación depende de un Space de terceros. Las colas, límites, parámetros y disponibilidad pueden cambiar.
- No se incluye una API paga ni se promete generación ilimitada.
- La web no necesita que pegues tokens secretos en el navegador. No publiques claves privadas.

## Cómo probarla en tu celular

### Opción A: abrir localmente
1. Descomprimí el ZIP.
2. Abrí `index.html` en un navegador moderno. Si el navegador bloquea módulos al abrir archivos locales, usá la opción B.

### Opción B: publicarla gratis con GitHub Pages
1. Creá una cuenta en https://github.com si todavía no tenés.
2. Creá un repositorio nuevo, por ejemplo `videoia-gratis`.
3. Subí `index.html` y `README.md` al repositorio.
4. Entrá a **Settings → Pages**.
5. En **Build and deployment**, elegí **Deploy from a branch**, seleccioná `main` y `/ (root)`, y guardá.
6. GitHub te dará una URL pública. Abrila desde el celular y usá “Agregar a pantalla de inicio” para tener un acceso tipo app.

## Conectar el motor de generación
1. Entrá a https://huggingface.co/spaces y buscá un Space público de generación de video con Gradio.
2. Abrí el Space y buscá **Use via API**. Confirmá que esté activo y que ofrezca la tarea que querés usar.
3. Copiá el identificador del Space con formato `usuario/nombre-del-space`.
4. En VideoIA, abrí **Configurar motor gratuito** y completá:
   - Space de Hugging Face.
   - Nombre exacto de la función API para texto a video (por ejemplo, `/text_to_video`, solo si esa es la función que muestra el Space).
   - Nombre exacto de la función API para imagen a video (por ejemplo, `/image_to_video`, solo si existe).
   - Orden de argumentos que espera la API de imagen a video.
5. Guardá y probá con una descripción breve.

**Ojo:** cada Space tiene sus propios parámetros. Esta versión manda `[prompt]` para texto y `[imagen, prompt]` o `[prompt, imagen]` para imagen. Si el Space requiere más argumentos (duración, semilla, resolución, etc.) o espera otro formato de archivo, hay que adaptar el código. El nombre y el orden deben verificarse en “Use via API”; no existe un endpoint universal para todos los modelos.

## Privacidad y límites
- La configuración se guarda en el almacenamiento local del navegador.
- La imagen elegida se envía al Space externo configurado para generar el video.
- No subas imágenes privadas, documentos, caras de menores ni material sensible.
- Un Space público puede apagarse, cambiar de API o limitar solicitudes. Si falla, probá otro Space compatible.
- Para una app pública con usuarios, límites por persona y almacenamiento de videos, haría falta agregar backend y protección contra abuso.

## Archivos
- `index.html`: interfaz responsive y lógica de conexión mediante `@gradio/client` cargado desde CDN.
